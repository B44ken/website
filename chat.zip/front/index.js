const $ = e => document.querySelector(e)
const ws = new WebSocket('ws://localhost:81')

ws.addEventListener('message', msg => {
        $('.messages').textContent += msg.data + '\n'
    })

const sendMessage = () => {
    ws.send(JSON.stringify({
        msg: $('.message').value, 
        name: $('.username').value 
    }))
}   