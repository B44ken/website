const ws = require('ws')

const wss = new ws.Server({ 'port': 81 })

var serversList = []

wss.on('connection', server => {
	serversList.push(server)
	server.on('message', packet => {
			try {
				const { name, msg } = JSON.parse(packet)
				void(name.v, msg.v) // check these values exist
				for(s of serversList)
					s.send(name + ': ' + msg)
			} catch(err) { console.error(err) }
		})
	server.send('connected!')
})


