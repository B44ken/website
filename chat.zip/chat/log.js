var chatLog = []

const send = (usr, msg) => 
	chatLog.push({
		usr: usr,
		msg: msg,
		id: chatLog.length + 1
	})
	return id
}
