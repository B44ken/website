const ws = require('ws')

const wss = new ws.Server({ 'port': 81 })

var serversList = []

wss.on('connection', server => {
	serversList.push(server)
	server.on('message', 
		msg => {
			try {
				var { name, msg } = JSON.parse(msg)
				console.log(`name: ${name+'\n'}message: ${msg}`)
				for(s of serversList) {
				    s.send(name + ': ' + msg)
				}
			} catch(err) { throw err }
		})
	server.send('connected!')
})


